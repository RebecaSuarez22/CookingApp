package model;

public enum TypeRecipe {
    Breakfast, Lunch, Dinner, Dessert, Drink
}
