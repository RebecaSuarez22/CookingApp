package model;

public class Instruction {
    String step;
    
    public Instruction(String step){
        this.step = step;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }
    
    
}
