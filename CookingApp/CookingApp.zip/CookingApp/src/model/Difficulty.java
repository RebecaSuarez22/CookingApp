package model;

public enum Difficulty {
    Easy, Normal, Hard
}
